// 'use strict';
// app.factory('logoutService',[function(){
// 	return {
// 		destroy:function(key){
// 			return sessionStorage.removeItem(key);
// 		}
// 	};

// }])


