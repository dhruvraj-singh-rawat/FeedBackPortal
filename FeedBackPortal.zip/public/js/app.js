angular.module('lnmApp', ['ui-router'])
	.config(function($stateProvider, $urlRouterProvider) {
		$stateProvider

			.state()
	})
